# -*- coding: utf-8 -*-
"""
Created on Wed Nov  6 19:31:44 2024
@author: Hp
"""

import tensorflow as tf
import cv2
import imutils
import numpy as np
import keras.utils
import pyttsx3
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
from PIL import ImageTk, Image
from tensorflow.keras.models import load_model
from keras.models import Sequential
from keras.layers import Conv2D
from keras.layers import MaxPooling2D
from keras.layers import Flatten
from keras.layers import Dense, Dropout
from keras import optimizers
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing.image import ImageDataGenerator

# Data augmentation for the training set and rescaling for the test set
train_datagen = ImageDataGenerator(
    rescale=1./255,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True)

test_datagen = ImageDataGenerator(rescale=1./255)

# Loading the training and test sets from the directories
training_set = train_datagen.flow_from_directory(
    "C:/projects/sign language/dataset/training_set",
    target_size=(64, 64),
    batch_size=32,
    class_mode='categorical')

test_set = test_datagen.flow_from_directory(
    "C:/projects/sign language/dataset/test_set",
    target_size=(64, 64),
    batch_size=32,
    class_mode='categorical')

# Building the CNN model
classifier = Sequential()

# Step 1 - Convolution Layer 
from tensorflow.keras.layers import Input
classifier.add(Input(shape=(64, 64, 3)))
classifier.add(Conv2D(32, (3, 3), activation='relu'))

# Step 2 - Pooling
classifier.add(MaxPooling2D(pool_size=(2, 2)))

# Adding second convolution layer
classifier.add(Conv2D(32, (3, 3), activation='relu'))
classifier.add(MaxPooling2D(pool_size=(2, 2)))

# Adding third convolution layer
classifier.add(Conv2D(64, (3, 3), activation='relu'))
classifier.add(MaxPooling2D(pool_size=(2, 2)))

# Step 3 - Flattening
classifier.add(Flatten())

# Step 4 - Full Connection
classifier.add(Dense(256, activation='relu'))
classifier.add(Dropout(0.5))
classifier.add(Dense(26, activation='softmax'))  # Output layer for 26 classes

# Compiling the CNN
classifier.compile(
    optimizer=optimizers.SGD(learning_rate=0.01),
    loss='categorical_crossentropy',
    metrics=['accuracy'])

# Training the model
model = classifier.fit(
    training_set,
    steps_per_epoch=800,
    epochs=20,
    validation_data=test_set,
    validation_steps=6500)

# Plotting training and validation accuracy
plt.plot(model.history['accuracy'], label='Training Accuracy')
plt.plot(model.history['val_accuracy'], label='Validation Accuracy')
plt.title('Model Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()
plt.show()

# Plotting training and validation loss
plt.plot(model.history['loss'], label='Training Loss')
plt.plot(model.history['val_loss'], label='Validation Loss')
plt.title('Model Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.show()

# Tkinter GUI setup
r = Tk()
sent = []
labels = []
bg = None

# Open file function
def openfile():
    global labels
    d1 = {'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4, 'F': 5, 'G': 6, 'H': 7, 'I': 8, 'J': 9, 'K': 10, 'L': 11, 'M': 12, 'N': 13, 'O': 14, 'P': 15,
          'Q': 16, 'R': 17, 'S': 18, 'T': 19, 'U': 20, 'V': 21, 'W': 22, 'X': 23, 'Y': 24, 'Z': 25}
    f1 = filedialog.askopenfilename()
    image = cv2.imread(f1)
    res = tf.image.resize(image, (64, 64))
    new_model = load_model('modelslr.h5')
    pred = new_model.predict(np.expand_dims(res / 255, 0))
    y = np.argmax(pred)
    y1 = list(filter(lambda x: d1[x] == y, d1))[0]
    global sent
    sent.append(y1)
    label = Label(r, text="The character predicted is:" + y1, font=('Helvetica', 14, 'bold'))
    labels.append(label)
    label.pack()
    engine = pyttsx3.init()
    engine.say("The character predicted is:" + y1)
    engine.runAndWait()

# Function to segment the hand
def segment(image, threshold=25):
    global bg
    diff = cv2.absdiff(bg.astype("uint8"), image)
    thresholded = cv2.threshold(diff, threshold, 255, cv2.THRESH_BINARY)[1]
    (cnts, _) = cv2.findContours(thresholded.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if len(cnts) == 0:
        return
    else:
        segmented = max(cnts, key=cv2.contourArea)
        return (thresholded, segmented)

# Running average function
def run_avg(image, aWeight):
    global bg
    if bg is None:
        bg = image.copy().astype("float")
        return
    cv2.accumulateWeighted(image, bg, aWeight)

# Detect hand function
def dtect_hand():
    try:
        aWeight = 0.5
        camera = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        top, right, bottom, left = 10, 350, 225, 590
        num_frames = 0
        while(True):
            (grabbed, frame) = camera.read()
            frame = imutils.resize(frame, width=700)
            frame = cv2.flip(frame, 1)
            clone = frame.copy()
            (height, width) = frame.shape[:2]
            roi = frame[top:bottom, right:left]
            gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
            gray = cv2.GaussianBlur(gray, (7, 7), 0)
            if num_frames < 30:
                run_avg(gray, aWeight)
            else:
                hand = segment(gray)
                if hand is not None:
                    (thresholded, segmented) = hand
                    cv2.drawContours(clone, [segmented + (right, top)], -1, (0, 0, 255))
                    cv2.imshow("Thesholded", thresholded)
            cv2.rectangle(clone, (left, top), (right, bottom), (0, 255, 0), 2)
            num_frames += 1
            cv2.imshow("Video Feed", clone)
            keypress = cv2.waitKey(1) & 0xFF
            if keypress % 256 == 32:
                img_name = "Clicked_image.png"
                cv2.imwrite(img_name, thresholded)
                new_model = load_model('modelslr.h5')
                test_image = keras.utils.load_img('./Clicked_image.png')
                test_image1 = keras.utils.img_to_array(test_image)
                res = tf.image.resize(test_image1, (64, 64))
                pred = new_model.predict(np.expand_dims(res / 255, 0))
                y = np.argmax(pred)
                d1 = {'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4, 'F': 5, 'G': 6, 'H': 7, 'I': 8, 'J': 9, 'K': 10, 'L': 11, 'M': 12, 'N': 13, 'O': 14, 'P': 15,
                      'Q': 16, 'R': 17, 'S': 18, 'T': 19, 'U': 20, 'V': 21, 'W': 22, 'X': 23, 'Y': 24, 'Z': 25}
                y1 = list(filter(lambda x: d1[x] == y, d1))[0]
                global sent
                global labels
                sent.append(y1)
                out = Label(r, text="The character predicted is:" + y1, font=('Helvetica', 14, 'bold'))
                labels.append(out)
                out.pack(side=TOP)
                engine = pyttsx3.init()
                engine.say("The character predicted is:" + y1)
                engine.runAndWait()
                camera.release()
                cv2.destroyAllWindows()
                break
            if keypress == ord("q"):
                camera.release()
                cv2.destroyAllWindows()
                break
    except:
        messagebox.showwarning("WARNING", "PLEASE SHOW YOUR HAND INSIDE THE BOUNDING BOX!")
        camera.release()
        cv2.destroyAllWindows()

# Function to delete the label
def delete_label(label):
    global labels
    global sent
    labels.remove(label)
    del sent[-1]
    label.destroy()

# Output function
def output():
    new_window = Toplevel()
    new_window.geometry('400x300')
    global labels
    global sent
    str1 = "".join(sent)
    show1 = Label(new_window, text="The Word is: " + str1, font=('Helvetica', 17, 'bold'))
    show1.pack()
    engine1 = pyttsx3.init()
    engine1.say("The Word is:" + str1)
    engine1.runAndWait()
    frame1 = Frame(new_window, width=300, height=400)
    frame1.pack()
    frame1.place()
    img1 = ImageTk.PhotoImage(Image.open("C:/projects/sign language/dataset-cover.png"), master=new_window)
    labelf = Label(frame1, image=img1)
    labelf.pack()
    new_window.mainloop()

# Tkinter GUI setup
l1 = Label(r, text="SIGN LANGUAGE RECOGNITION SYSTEM", font=('Helvetica', 24, 'bold'))
l1.pack()

# Buttons
bs = Button(r, text='OPEN CAMERA', width=27, bg='yellow', command=dtect_hand, font=('Helvetica', 10, 'bold'))
bs.pack(side=TOP)
bs1 = Button(r, text="OPEN FILE", width=27, bg='yellow', command=openfile, font=('Helvetica', 10, 'bold'))
bs1.pack(side=TOP)
bs3 = Button(r, text='SHOW', width=27, bg='yellow', command=output, font=('Helvetica', 10, 'bold'))
bs3.pack(side=TOP)
bs4 = Button(r, text='DELETE', width=27, bg='yellow', command=lambda: delete_label(labels[-1]), font=('Helvetica', 10, 'bold'))
bs4.pack(side=TOP)

# Image display frame
frame = Frame(r, width=300, height=400)
frame.pack()
frame.place()

img = ImageTk.PhotoImage(Image.open("C:/projects/sign language/dataset-cover.png"), master=r)
label = Label(frame, image=img)
label.pack()

r.mainloop()
